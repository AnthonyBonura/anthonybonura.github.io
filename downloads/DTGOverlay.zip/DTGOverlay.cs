#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private DTGOverlay[] cacheDTGOverlay;

		
		public DTGOverlay DTGOverlay(Brush ballColorUp, Brush ballColorDown, int ballOffset, bool ballVisible, Brush dblBarColorUp, Brush dblBarColorDown, int dblBarOffset, bool dblBarVisible, Brush dojiColorUp, Brush dojiColorDown, int dojiOffset, bool dojiVisible, int eMASPeriod, Brush eMASColorUp, Brush eMASColorDown, bool eMASVisible, int eMALPeriod, Brush eMALColorUp, Brush eMALColorDown, bool eMALVisible, Brush pinbarColorUp, Brush pinbarColorDown, int pinbarOffset, bool pinbarVisible, Brush pivotPointColorUp, Brush pivotPointColorDown, int pivotPointOffset, bool pivotPointVisible, Brush turningPointColorUp, Brush turningPointColorDown, int turningPointOffset, bool turningPointVisible)
		{
			return DTGOverlay(Input, ballColorUp, ballColorDown, ballOffset, ballVisible, dblBarColorUp, dblBarColorDown, dblBarOffset, dblBarVisible, dojiColorUp, dojiColorDown, dojiOffset, dojiVisible, eMASPeriod, eMASColorUp, eMASColorDown, eMASVisible, eMALPeriod, eMALColorUp, eMALColorDown, eMALVisible, pinbarColorUp, pinbarColorDown, pinbarOffset, pinbarVisible, pivotPointColorUp, pivotPointColorDown, pivotPointOffset, pivotPointVisible, turningPointColorUp, turningPointColorDown, turningPointOffset, turningPointVisible);
		}


		
		public DTGOverlay DTGOverlay(ISeries<double> input, Brush ballColorUp, Brush ballColorDown, int ballOffset, bool ballVisible, Brush dblBarColorUp, Brush dblBarColorDown, int dblBarOffset, bool dblBarVisible, Brush dojiColorUp, Brush dojiColorDown, int dojiOffset, bool dojiVisible, int eMASPeriod, Brush eMASColorUp, Brush eMASColorDown, bool eMASVisible, int eMALPeriod, Brush eMALColorUp, Brush eMALColorDown, bool eMALVisible, Brush pinbarColorUp, Brush pinbarColorDown, int pinbarOffset, bool pinbarVisible, Brush pivotPointColorUp, Brush pivotPointColorDown, int pivotPointOffset, bool pivotPointVisible, Brush turningPointColorUp, Brush turningPointColorDown, int turningPointOffset, bool turningPointVisible)
		{
			if (cacheDTGOverlay != null)
				for (int idx = 0; idx < cacheDTGOverlay.Length; idx++)
					if (cacheDTGOverlay[idx].BallColorUp == ballColorUp && cacheDTGOverlay[idx].BallColorDown == ballColorDown && cacheDTGOverlay[idx].BallOffset == ballOffset && cacheDTGOverlay[idx].BallVisible == ballVisible && cacheDTGOverlay[idx].DblBarColorUp == dblBarColorUp && cacheDTGOverlay[idx].DblBarColorDown == dblBarColorDown && cacheDTGOverlay[idx].DblBarOffset == dblBarOffset && cacheDTGOverlay[idx].DblBarVisible == dblBarVisible && cacheDTGOverlay[idx].DojiColorUp == dojiColorUp && cacheDTGOverlay[idx].DojiColorDown == dojiColorDown && cacheDTGOverlay[idx].DojiOffset == dojiOffset && cacheDTGOverlay[idx].DojiVisible == dojiVisible && cacheDTGOverlay[idx].EMASPeriod == eMASPeriod && cacheDTGOverlay[idx].EMASColorUp == eMASColorUp && cacheDTGOverlay[idx].EMASColorDown == eMASColorDown && cacheDTGOverlay[idx].EMASVisible == eMASVisible && cacheDTGOverlay[idx].EMALPeriod == eMALPeriod && cacheDTGOverlay[idx].EMALColorUp == eMALColorUp && cacheDTGOverlay[idx].EMALColorDown == eMALColorDown && cacheDTGOverlay[idx].EMALVisible == eMALVisible && cacheDTGOverlay[idx].PinbarColorUp == pinbarColorUp && cacheDTGOverlay[idx].PinbarColorDown == pinbarColorDown && cacheDTGOverlay[idx].PinbarOffset == pinbarOffset && cacheDTGOverlay[idx].PinbarVisible == pinbarVisible && cacheDTGOverlay[idx].PivotPointColorUp == pivotPointColorUp && cacheDTGOverlay[idx].PivotPointColorDown == pivotPointColorDown && cacheDTGOverlay[idx].PivotPointOffset == pivotPointOffset && cacheDTGOverlay[idx].PivotPointVisible == pivotPointVisible && cacheDTGOverlay[idx].TurningPointColorUp == turningPointColorUp && cacheDTGOverlay[idx].TurningPointColorDown == turningPointColorDown && cacheDTGOverlay[idx].TurningPointOffset == turningPointOffset && cacheDTGOverlay[idx].TurningPointVisible == turningPointVisible && cacheDTGOverlay[idx].EqualsInput(input))
						return cacheDTGOverlay[idx];
			return CacheIndicator<DTGOverlay>(new DTGOverlay(){ BallColorUp = ballColorUp, BallColorDown = ballColorDown, BallOffset = ballOffset, BallVisible = ballVisible, DblBarColorUp = dblBarColorUp, DblBarColorDown = dblBarColorDown, DblBarOffset = dblBarOffset, DblBarVisible = dblBarVisible, DojiColorUp = dojiColorUp, DojiColorDown = dojiColorDown, DojiOffset = dojiOffset, DojiVisible = dojiVisible, EMASPeriod = eMASPeriod, EMASColorUp = eMASColorUp, EMASColorDown = eMASColorDown, EMASVisible = eMASVisible, EMALPeriod = eMALPeriod, EMALColorUp = eMALColorUp, EMALColorDown = eMALColorDown, EMALVisible = eMALVisible, PinbarColorUp = pinbarColorUp, PinbarColorDown = pinbarColorDown, PinbarOffset = pinbarOffset, PinbarVisible = pinbarVisible, PivotPointColorUp = pivotPointColorUp, PivotPointColorDown = pivotPointColorDown, PivotPointOffset = pivotPointOffset, PivotPointVisible = pivotPointVisible, TurningPointColorUp = turningPointColorUp, TurningPointColorDown = turningPointColorDown, TurningPointOffset = turningPointOffset, TurningPointVisible = turningPointVisible }, input, ref cacheDTGOverlay);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.DTGOverlay DTGOverlay(Brush ballColorUp, Brush ballColorDown, int ballOffset, bool ballVisible, Brush dblBarColorUp, Brush dblBarColorDown, int dblBarOffset, bool dblBarVisible, Brush dojiColorUp, Brush dojiColorDown, int dojiOffset, bool dojiVisible, int eMASPeriod, Brush eMASColorUp, Brush eMASColorDown, bool eMASVisible, int eMALPeriod, Brush eMALColorUp, Brush eMALColorDown, bool eMALVisible, Brush pinbarColorUp, Brush pinbarColorDown, int pinbarOffset, bool pinbarVisible, Brush pivotPointColorUp, Brush pivotPointColorDown, int pivotPointOffset, bool pivotPointVisible, Brush turningPointColorUp, Brush turningPointColorDown, int turningPointOffset, bool turningPointVisible)
		{
			return indicator.DTGOverlay(Input, ballColorUp, ballColorDown, ballOffset, ballVisible, dblBarColorUp, dblBarColorDown, dblBarOffset, dblBarVisible, dojiColorUp, dojiColorDown, dojiOffset, dojiVisible, eMASPeriod, eMASColorUp, eMASColorDown, eMASVisible, eMALPeriod, eMALColorUp, eMALColorDown, eMALVisible, pinbarColorUp, pinbarColorDown, pinbarOffset, pinbarVisible, pivotPointColorUp, pivotPointColorDown, pivotPointOffset, pivotPointVisible, turningPointColorUp, turningPointColorDown, turningPointOffset, turningPointVisible);
		}


		
		public Indicators.DTGOverlay DTGOverlay(ISeries<double> input , Brush ballColorUp, Brush ballColorDown, int ballOffset, bool ballVisible, Brush dblBarColorUp, Brush dblBarColorDown, int dblBarOffset, bool dblBarVisible, Brush dojiColorUp, Brush dojiColorDown, int dojiOffset, bool dojiVisible, int eMASPeriod, Brush eMASColorUp, Brush eMASColorDown, bool eMASVisible, int eMALPeriod, Brush eMALColorUp, Brush eMALColorDown, bool eMALVisible, Brush pinbarColorUp, Brush pinbarColorDown, int pinbarOffset, bool pinbarVisible, Brush pivotPointColorUp, Brush pivotPointColorDown, int pivotPointOffset, bool pivotPointVisible, Brush turningPointColorUp, Brush turningPointColorDown, int turningPointOffset, bool turningPointVisible)
		{
			return indicator.DTGOverlay(input, ballColorUp, ballColorDown, ballOffset, ballVisible, dblBarColorUp, dblBarColorDown, dblBarOffset, dblBarVisible, dojiColorUp, dojiColorDown, dojiOffset, dojiVisible, eMASPeriod, eMASColorUp, eMASColorDown, eMASVisible, eMALPeriod, eMALColorUp, eMALColorDown, eMALVisible, pinbarColorUp, pinbarColorDown, pinbarOffset, pinbarVisible, pivotPointColorUp, pivotPointColorDown, pivotPointOffset, pivotPointVisible, turningPointColorUp, turningPointColorDown, turningPointOffset, turningPointVisible);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.DTGOverlay DTGOverlay(Brush ballColorUp, Brush ballColorDown, int ballOffset, bool ballVisible, Brush dblBarColorUp, Brush dblBarColorDown, int dblBarOffset, bool dblBarVisible, Brush dojiColorUp, Brush dojiColorDown, int dojiOffset, bool dojiVisible, int eMASPeriod, Brush eMASColorUp, Brush eMASColorDown, bool eMASVisible, int eMALPeriod, Brush eMALColorUp, Brush eMALColorDown, bool eMALVisible, Brush pinbarColorUp, Brush pinbarColorDown, int pinbarOffset, bool pinbarVisible, Brush pivotPointColorUp, Brush pivotPointColorDown, int pivotPointOffset, bool pivotPointVisible, Brush turningPointColorUp, Brush turningPointColorDown, int turningPointOffset, bool turningPointVisible)
		{
			return indicator.DTGOverlay(Input, ballColorUp, ballColorDown, ballOffset, ballVisible, dblBarColorUp, dblBarColorDown, dblBarOffset, dblBarVisible, dojiColorUp, dojiColorDown, dojiOffset, dojiVisible, eMASPeriod, eMASColorUp, eMASColorDown, eMASVisible, eMALPeriod, eMALColorUp, eMALColorDown, eMALVisible, pinbarColorUp, pinbarColorDown, pinbarOffset, pinbarVisible, pivotPointColorUp, pivotPointColorDown, pivotPointOffset, pivotPointVisible, turningPointColorUp, turningPointColorDown, turningPointOffset, turningPointVisible);
		}


		
		public Indicators.DTGOverlay DTGOverlay(ISeries<double> input , Brush ballColorUp, Brush ballColorDown, int ballOffset, bool ballVisible, Brush dblBarColorUp, Brush dblBarColorDown, int dblBarOffset, bool dblBarVisible, Brush dojiColorUp, Brush dojiColorDown, int dojiOffset, bool dojiVisible, int eMASPeriod, Brush eMASColorUp, Brush eMASColorDown, bool eMASVisible, int eMALPeriod, Brush eMALColorUp, Brush eMALColorDown, bool eMALVisible, Brush pinbarColorUp, Brush pinbarColorDown, int pinbarOffset, bool pinbarVisible, Brush pivotPointColorUp, Brush pivotPointColorDown, int pivotPointOffset, bool pivotPointVisible, Brush turningPointColorUp, Brush turningPointColorDown, int turningPointOffset, bool turningPointVisible)
		{
			return indicator.DTGOverlay(input, ballColorUp, ballColorDown, ballOffset, ballVisible, dblBarColorUp, dblBarColorDown, dblBarOffset, dblBarVisible, dojiColorUp, dojiColorDown, dojiOffset, dojiVisible, eMASPeriod, eMASColorUp, eMASColorDown, eMASVisible, eMALPeriod, eMALColorUp, eMALColorDown, eMALVisible, pinbarColorUp, pinbarColorDown, pinbarOffset, pinbarVisible, pivotPointColorUp, pivotPointColorDown, pivotPointOffset, pivotPointVisible, turningPointColorUp, turningPointColorDown, turningPointOffset, turningPointVisible);
		}

	}
}

#endregion
