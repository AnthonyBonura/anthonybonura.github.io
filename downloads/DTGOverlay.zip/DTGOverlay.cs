#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private DTGOverlay[] cacheDTGOverlay;

		
		public DTGOverlay DTGOverlay(Brush ballColorUp, Brush ballColorDown, int ballOffset, int ballSize, bool ballVisible, Brush dblBarColorUp, Brush dblBarColorDown, int dblBarOffset, int dblBarSize, bool dblBarVisible, Brush dojiColorUp, Brush dojiColorDown, int dojiOffset, int dojiSize, bool dojiVisible, int eMASPeriod, Brush eMASColorUp, Brush eMASColorDown, int eMASSize, bool eMASVisible, int eMALPeriod, Brush eMALColorUp, Brush eMALColorDown, int eMALSize, bool eMALVisible, Brush pinbarColorUp, Brush pinbarColorDown, int pinbarOffset, int pinbarSize, bool pinbarVisible, Brush pivotPointColorUp, Brush pivotPointColorDown, int pivotPointOffset, int pivotPointSize, bool pivotPointVisible, Brush turningPointColorUp, Brush turningPointColorDown, int turningPointOffset, bool turningPointVisible)
		{
			return DTGOverlay(Input, ballColorUp, ballColorDown, ballOffset, ballSize, ballVisible, dblBarColorUp, dblBarColorDown, dblBarOffset, dblBarSize, dblBarVisible, dojiColorUp, dojiColorDown, dojiOffset, dojiSize, dojiVisible, eMASPeriod, eMASColorUp, eMASColorDown, eMASSize, eMASVisible, eMALPeriod, eMALColorUp, eMALColorDown, eMALSize, eMALVisible, pinbarColorUp, pinbarColorDown, pinbarOffset, pinbarSize, pinbarVisible, pivotPointColorUp, pivotPointColorDown, pivotPointOffset, pivotPointSize, pivotPointVisible, turningPointColorUp, turningPointColorDown, turningPointOffset, turningPointVisible);
		}


		
		public DTGOverlay DTGOverlay(ISeries<double> input, Brush ballColorUp, Brush ballColorDown, int ballOffset, int ballSize, bool ballVisible, Brush dblBarColorUp, Brush dblBarColorDown, int dblBarOffset, int dblBarSize, bool dblBarVisible, Brush dojiColorUp, Brush dojiColorDown, int dojiOffset, int dojiSize, bool dojiVisible, int eMASPeriod, Brush eMASColorUp, Brush eMASColorDown, int eMASSize, bool eMASVisible, int eMALPeriod, Brush eMALColorUp, Brush eMALColorDown, int eMALSize, bool eMALVisible, Brush pinbarColorUp, Brush pinbarColorDown, int pinbarOffset, int pinbarSize, bool pinbarVisible, Brush pivotPointColorUp, Brush pivotPointColorDown, int pivotPointOffset, int pivotPointSize, bool pivotPointVisible, Brush turningPointColorUp, Brush turningPointColorDown, int turningPointOffset, bool turningPointVisible)
		{
			if (cacheDTGOverlay != null)
				for (int idx = 0; idx < cacheDTGOverlay.Length; idx++)
					if (cacheDTGOverlay[idx].BallColorUp == ballColorUp && cacheDTGOverlay[idx].BallColorDown == ballColorDown && cacheDTGOverlay[idx].BallOffset == ballOffset && cacheDTGOverlay[idx].BallSize == ballSize && cacheDTGOverlay[idx].BallVisible == ballVisible && cacheDTGOverlay[idx].DblBarColorUp == dblBarColorUp && cacheDTGOverlay[idx].DblBarColorDown == dblBarColorDown && cacheDTGOverlay[idx].DblBarOffset == dblBarOffset && cacheDTGOverlay[idx].DblBarSize == dblBarSize && cacheDTGOverlay[idx].DblBarVisible == dblBarVisible && cacheDTGOverlay[idx].DojiColorUp == dojiColorUp && cacheDTGOverlay[idx].DojiColorDown == dojiColorDown && cacheDTGOverlay[idx].DojiOffset == dojiOffset && cacheDTGOverlay[idx].DojiSize == dojiSize && cacheDTGOverlay[idx].DojiVisible == dojiVisible && cacheDTGOverlay[idx].EMASPeriod == eMASPeriod && cacheDTGOverlay[idx].EMASColorUp == eMASColorUp && cacheDTGOverlay[idx].EMASColorDown == eMASColorDown && cacheDTGOverlay[idx].EMASSize == eMASSize && cacheDTGOverlay[idx].EMASVisible == eMASVisible && cacheDTGOverlay[idx].EMALPeriod == eMALPeriod && cacheDTGOverlay[idx].EMALColorUp == eMALColorUp && cacheDTGOverlay[idx].EMALColorDown == eMALColorDown && cacheDTGOverlay[idx].EMALSize == eMALSize && cacheDTGOverlay[idx].EMALVisible == eMALVisible && cacheDTGOverlay[idx].PinbarColorUp == pinbarColorUp && cacheDTGOverlay[idx].PinbarColorDown == pinbarColorDown && cacheDTGOverlay[idx].PinbarOffset == pinbarOffset && cacheDTGOverlay[idx].PinbarSize == pinbarSize && cacheDTGOverlay[idx].PinbarVisible == pinbarVisible && cacheDTGOverlay[idx].PivotPointColorUp == pivotPointColorUp && cacheDTGOverlay[idx].PivotPointColorDown == pivotPointColorDown && cacheDTGOverlay[idx].PivotPointOffset == pivotPointOffset && cacheDTGOverlay[idx].PivotPointSize == pivotPointSize && cacheDTGOverlay[idx].PivotPointVisible == pivotPointVisible && cacheDTGOverlay[idx].TurningPointColorUp == turningPointColorUp && cacheDTGOverlay[idx].TurningPointColorDown == turningPointColorDown && cacheDTGOverlay[idx].TurningPointOffset == turningPointOffset && cacheDTGOverlay[idx].TurningPointVisible == turningPointVisible && cacheDTGOverlay[idx].EqualsInput(input))
						return cacheDTGOverlay[idx];
			return CacheIndicator<DTGOverlay>(new DTGOverlay(){ BallColorUp = ballColorUp, BallColorDown = ballColorDown, BallOffset = ballOffset, BallSize = ballSize, BallVisible = ballVisible, DblBarColorUp = dblBarColorUp, DblBarColorDown = dblBarColorDown, DblBarOffset = dblBarOffset, DblBarSize = dblBarSize, DblBarVisible = dblBarVisible, DojiColorUp = dojiColorUp, DojiColorDown = dojiColorDown, DojiOffset = dojiOffset, DojiSize = dojiSize, DojiVisible = dojiVisible, EMASPeriod = eMASPeriod, EMASColorUp = eMASColorUp, EMASColorDown = eMASColorDown, EMASSize = eMASSize, EMASVisible = eMASVisible, EMALPeriod = eMALPeriod, EMALColorUp = eMALColorUp, EMALColorDown = eMALColorDown, EMALSize = eMALSize, EMALVisible = eMALVisible, PinbarColorUp = pinbarColorUp, PinbarColorDown = pinbarColorDown, PinbarOffset = pinbarOffset, PinbarSize = pinbarSize, PinbarVisible = pinbarVisible, PivotPointColorUp = pivotPointColorUp, PivotPointColorDown = pivotPointColorDown, PivotPointOffset = pivotPointOffset, PivotPointSize = pivotPointSize, PivotPointVisible = pivotPointVisible, TurningPointColorUp = turningPointColorUp, TurningPointColorDown = turningPointColorDown, TurningPointOffset = turningPointOffset, TurningPointVisible = turningPointVisible }, input, ref cacheDTGOverlay);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.DTGOverlay DTGOverlay(Brush ballColorUp, Brush ballColorDown, int ballOffset, int ballSize, bool ballVisible, Brush dblBarColorUp, Brush dblBarColorDown, int dblBarOffset, int dblBarSize, bool dblBarVisible, Brush dojiColorUp, Brush dojiColorDown, int dojiOffset, int dojiSize, bool dojiVisible, int eMASPeriod, Brush eMASColorUp, Brush eMASColorDown, int eMASSize, bool eMASVisible, int eMALPeriod, Brush eMALColorUp, Brush eMALColorDown, int eMALSize, bool eMALVisible, Brush pinbarColorUp, Brush pinbarColorDown, int pinbarOffset, int pinbarSize, bool pinbarVisible, Brush pivotPointColorUp, Brush pivotPointColorDown, int pivotPointOffset, int pivotPointSize, bool pivotPointVisible, Brush turningPointColorUp, Brush turningPointColorDown, int turningPointOffset, bool turningPointVisible)
		{
			return indicator.DTGOverlay(Input, ballColorUp, ballColorDown, ballOffset, ballSize, ballVisible, dblBarColorUp, dblBarColorDown, dblBarOffset, dblBarSize, dblBarVisible, dojiColorUp, dojiColorDown, dojiOffset, dojiSize, dojiVisible, eMASPeriod, eMASColorUp, eMASColorDown, eMASSize, eMASVisible, eMALPeriod, eMALColorUp, eMALColorDown, eMALSize, eMALVisible, pinbarColorUp, pinbarColorDown, pinbarOffset, pinbarSize, pinbarVisible, pivotPointColorUp, pivotPointColorDown, pivotPointOffset, pivotPointSize, pivotPointVisible, turningPointColorUp, turningPointColorDown, turningPointOffset, turningPointVisible);
		}


		
		public Indicators.DTGOverlay DTGOverlay(ISeries<double> input , Brush ballColorUp, Brush ballColorDown, int ballOffset, int ballSize, bool ballVisible, Brush dblBarColorUp, Brush dblBarColorDown, int dblBarOffset, int dblBarSize, bool dblBarVisible, Brush dojiColorUp, Brush dojiColorDown, int dojiOffset, int dojiSize, bool dojiVisible, int eMASPeriod, Brush eMASColorUp, Brush eMASColorDown, int eMASSize, bool eMASVisible, int eMALPeriod, Brush eMALColorUp, Brush eMALColorDown, int eMALSize, bool eMALVisible, Brush pinbarColorUp, Brush pinbarColorDown, int pinbarOffset, int pinbarSize, bool pinbarVisible, Brush pivotPointColorUp, Brush pivotPointColorDown, int pivotPointOffset, int pivotPointSize, bool pivotPointVisible, Brush turningPointColorUp, Brush turningPointColorDown, int turningPointOffset, bool turningPointVisible)
		{
			return indicator.DTGOverlay(input, ballColorUp, ballColorDown, ballOffset, ballSize, ballVisible, dblBarColorUp, dblBarColorDown, dblBarOffset, dblBarSize, dblBarVisible, dojiColorUp, dojiColorDown, dojiOffset, dojiSize, dojiVisible, eMASPeriod, eMASColorUp, eMASColorDown, eMASSize, eMASVisible, eMALPeriod, eMALColorUp, eMALColorDown, eMALSize, eMALVisible, pinbarColorUp, pinbarColorDown, pinbarOffset, pinbarSize, pinbarVisible, pivotPointColorUp, pivotPointColorDown, pivotPointOffset, pivotPointSize, pivotPointVisible, turningPointColorUp, turningPointColorDown, turningPointOffset, turningPointVisible);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.DTGOverlay DTGOverlay(Brush ballColorUp, Brush ballColorDown, int ballOffset, int ballSize, bool ballVisible, Brush dblBarColorUp, Brush dblBarColorDown, int dblBarOffset, int dblBarSize, bool dblBarVisible, Brush dojiColorUp, Brush dojiColorDown, int dojiOffset, int dojiSize, bool dojiVisible, int eMASPeriod, Brush eMASColorUp, Brush eMASColorDown, int eMASSize, bool eMASVisible, int eMALPeriod, Brush eMALColorUp, Brush eMALColorDown, int eMALSize, bool eMALVisible, Brush pinbarColorUp, Brush pinbarColorDown, int pinbarOffset, int pinbarSize, bool pinbarVisible, Brush pivotPointColorUp, Brush pivotPointColorDown, int pivotPointOffset, int pivotPointSize, bool pivotPointVisible, Brush turningPointColorUp, Brush turningPointColorDown, int turningPointOffset, bool turningPointVisible)
		{
			return indicator.DTGOverlay(Input, ballColorUp, ballColorDown, ballOffset, ballSize, ballVisible, dblBarColorUp, dblBarColorDown, dblBarOffset, dblBarSize, dblBarVisible, dojiColorUp, dojiColorDown, dojiOffset, dojiSize, dojiVisible, eMASPeriod, eMASColorUp, eMASColorDown, eMASSize, eMASVisible, eMALPeriod, eMALColorUp, eMALColorDown, eMALSize, eMALVisible, pinbarColorUp, pinbarColorDown, pinbarOffset, pinbarSize, pinbarVisible, pivotPointColorUp, pivotPointColorDown, pivotPointOffset, pivotPointSize, pivotPointVisible, turningPointColorUp, turningPointColorDown, turningPointOffset, turningPointVisible);
		}


		
		public Indicators.DTGOverlay DTGOverlay(ISeries<double> input , Brush ballColorUp, Brush ballColorDown, int ballOffset, int ballSize, bool ballVisible, Brush dblBarColorUp, Brush dblBarColorDown, int dblBarOffset, int dblBarSize, bool dblBarVisible, Brush dojiColorUp, Brush dojiColorDown, int dojiOffset, int dojiSize, bool dojiVisible, int eMASPeriod, Brush eMASColorUp, Brush eMASColorDown, int eMASSize, bool eMASVisible, int eMALPeriod, Brush eMALColorUp, Brush eMALColorDown, int eMALSize, bool eMALVisible, Brush pinbarColorUp, Brush pinbarColorDown, int pinbarOffset, int pinbarSize, bool pinbarVisible, Brush pivotPointColorUp, Brush pivotPointColorDown, int pivotPointOffset, int pivotPointSize, bool pivotPointVisible, Brush turningPointColorUp, Brush turningPointColorDown, int turningPointOffset, bool turningPointVisible)
		{
			return indicator.DTGOverlay(input, ballColorUp, ballColorDown, ballOffset, ballSize, ballVisible, dblBarColorUp, dblBarColorDown, dblBarOffset, dblBarSize, dblBarVisible, dojiColorUp, dojiColorDown, dojiOffset, dojiSize, dojiVisible, eMASPeriod, eMASColorUp, eMASColorDown, eMASSize, eMASVisible, eMALPeriod, eMALColorUp, eMALColorDown, eMALSize, eMALVisible, pinbarColorUp, pinbarColorDown, pinbarOffset, pinbarSize, pinbarVisible, pivotPointColorUp, pivotPointColorDown, pivotPointOffset, pivotPointSize, pivotPointVisible, turningPointColorUp, turningPointColorDown, turningPointOffset, turningPointVisible);
		}

	}
}

#endregion
